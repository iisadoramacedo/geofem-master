from .StaticUtils import *
