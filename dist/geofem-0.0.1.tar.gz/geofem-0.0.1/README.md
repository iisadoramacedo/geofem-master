Modelagem geofísica direta de campos eletromagnéticos via volumes finitos: MT e MCSEM.
